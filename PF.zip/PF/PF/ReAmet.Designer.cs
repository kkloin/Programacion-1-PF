﻿
namespace PF
{
    partial class ReAmet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label codigo_empleadoLabel;
            System.Windows.Forms.Label nombre_completoLabel;
            System.Windows.Forms.Label fecha_de_ingresoLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReAmet));
            this.gestion_infracciones1DataSet = new PF.gestion_infracciones1DataSet();
            this.aMETBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.aMETTableAdapter = new PF.gestion_infracciones1DataSetTableAdapters.AMETTableAdapter();
            this.tableAdapterManager = new PF.gestion_infracciones1DataSetTableAdapters.TableAdapterManager();
            this.codigo_empleadoTextBox = new System.Windows.Forms.TextBox();
            this.nombre_completoTextBox = new System.Windows.Forms.TextBox();
            this.fecha_de_ingresoDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            codigo_empleadoLabel = new System.Windows.Forms.Label();
            nombre_completoLabel = new System.Windows.Forms.Label();
            fecha_de_ingresoLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gestion_infracciones1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aMETBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gestion_infracciones1DataSet
            // 
            this.gestion_infracciones1DataSet.DataSetName = "gestion_infracciones1DataSet";
            this.gestion_infracciones1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // aMETBindingSource
            // 
            this.aMETBindingSource.DataMember = "AMET";
            this.aMETBindingSource.DataSource = this.gestion_infracciones1DataSet;
            // 
            // aMETTableAdapter
            // 
            this.aMETTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AMETTableAdapter = this.aMETTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ConductorTableAdapter = null;
            this.tableAdapterManager.registro_de_infraccionTableAdapter = null;
            this.tableAdapterManager.tipos_de_infraccionesTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = PF.gestion_infracciones1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.vehiculoTableAdapter = null;
            // 
            // codigo_empleadoLabel
            // 
            codigo_empleadoLabel.AutoSize = true;
            codigo_empleadoLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            codigo_empleadoLabel.Location = new System.Drawing.Point(147, 165);
            codigo_empleadoLabel.Name = "codigo_empleadoLabel";
            codigo_empleadoLabel.Size = new System.Drawing.Size(218, 33);
            codigo_empleadoLabel.TabIndex = 1;
            codigo_empleadoLabel.Text = "Codigo empleado:";
            // 
            // codigo_empleadoTextBox
            // 
            this.codigo_empleadoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.aMETBindingSource, "codigo_empleado", true));
            this.codigo_empleadoTextBox.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.codigo_empleadoTextBox.Location = new System.Drawing.Point(383, 162);
            this.codigo_empleadoTextBox.Name = "codigo_empleadoTextBox";
            this.codigo_empleadoTextBox.Size = new System.Drawing.Size(294, 39);
            this.codigo_empleadoTextBox.TabIndex = 2;
            // 
            // nombre_completoLabel
            // 
            nombre_completoLabel.AutoSize = true;
            nombre_completoLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            nombre_completoLabel.Location = new System.Drawing.Point(146, 238);
            nombre_completoLabel.Name = "nombre_completoLabel";
            nombre_completoLabel.Size = new System.Drawing.Size(221, 33);
            nombre_completoLabel.TabIndex = 3;
            nombre_completoLabel.Text = "Nombre completo:";
            // 
            // nombre_completoTextBox
            // 
            this.nombre_completoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.aMETBindingSource, "nombre_completo", true));
            this.nombre_completoTextBox.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombre_completoTextBox.Location = new System.Drawing.Point(383, 232);
            this.nombre_completoTextBox.Name = "nombre_completoTextBox";
            this.nombre_completoTextBox.Size = new System.Drawing.Size(294, 39);
            this.nombre_completoTextBox.TabIndex = 4;
            // 
            // fecha_de_ingresoLabel
            // 
            fecha_de_ingresoLabel.AutoSize = true;
            fecha_de_ingresoLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            fecha_de_ingresoLabel.Location = new System.Drawing.Point(145, 310);
            fecha_de_ingresoLabel.Name = "fecha_de_ingresoLabel";
            fecha_de_ingresoLabel.Size = new System.Drawing.Size(210, 33);
            fecha_de_ingresoLabel.TabIndex = 5;
            fecha_de_ingresoLabel.Text = "Fecha de ingreso:";
            // 
            // fecha_de_ingresoDateTimePicker
            // 
            this.fecha_de_ingresoDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.aMETBindingSource, "Fecha_de_ingreso", true));
            this.fecha_de_ingresoDateTimePicker.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fecha_de_ingresoDateTimePicker.Location = new System.Drawing.Point(383, 310);
            this.fecha_de_ingresoDateTimePicker.Name = "fecha_de_ingresoDateTimePicker";
            this.fecha_de_ingresoDateTimePicker.Size = new System.Drawing.Size(294, 39);
            this.fecha_de_ingresoDateTimePicker.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(269, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(296, 47);
            this.label2.TabIndex = 31;
            this.label2.Text = "Registrar AMETs";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightYellow;
            this.button3.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(164, 402);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(203, 62);
            this.button3.TabIndex = 32;
            this.button3.Text = "Registro";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightYellow;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(462, 402);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(203, 62);
            this.button1.TabIndex = 32;
            this.button1.Text = "Limpiar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(39, 48);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 74);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // ReAmet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(884, 529);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(fecha_de_ingresoLabel);
            this.Controls.Add(this.fecha_de_ingresoDateTimePicker);
            this.Controls.Add(nombre_completoLabel);
            this.Controls.Add(this.nombre_completoTextBox);
            this.Controls.Add(codigo_empleadoLabel);
            this.Controls.Add(this.codigo_empleadoTextBox);
            this.Name = "ReAmet";
            this.Text = "ReAmet";
            this.Load += new System.EventHandler(this.ReAmet_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gestion_infracciones1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aMETBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private gestion_infracciones1DataSet gestion_infracciones1DataSet;
        private System.Windows.Forms.BindingSource aMETBindingSource;
        private gestion_infracciones1DataSetTableAdapters.AMETTableAdapter aMETTableAdapter;
        private gestion_infracciones1DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox codigo_empleadoTextBox;
        private System.Windows.Forms.TextBox nombre_completoTextBox;
        private System.Windows.Forms.DateTimePicker fecha_de_ingresoDateTimePicker;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}