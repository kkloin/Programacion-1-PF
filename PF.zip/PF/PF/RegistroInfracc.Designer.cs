﻿
namespace PF
{
    partial class RegistroInfracc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label cedulaLabel;
            System.Windows.Forms.Label nombre_conductorLabel;
            System.Windows.Forms.Label placaLabel;
            System.Windows.Forms.Label tipo_licenciaLabel;
            System.Windows.Forms.Label codigo_AMETLabel;
            System.Windows.Forms.Label descripcion_infraccionesLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistroInfracc));
            this.gestion_infracciones1DataSet = new PF.gestion_infracciones1DataSet();
            this.registro_de_infraccionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.registro_de_infraccionTableAdapter = new PF.gestion_infracciones1DataSetTableAdapters.registro_de_infraccionTableAdapter();
            this.tableAdapterManager = new PF.gestion_infracciones1DataSetTableAdapters.TableAdapterManager();
            this.cedulaTextBox = new System.Windows.Forms.TextBox();
            this.nombre_conductorTextBox = new System.Windows.Forms.TextBox();
            this.placaTextBox = new System.Windows.Forms.TextBox();
            this.codigo_AMETTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            cedulaLabel = new System.Windows.Forms.Label();
            nombre_conductorLabel = new System.Windows.Forms.Label();
            placaLabel = new System.Windows.Forms.Label();
            tipo_licenciaLabel = new System.Windows.Forms.Label();
            codigo_AMETLabel = new System.Windows.Forms.Label();
            descripcion_infraccionesLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gestion_infracciones1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.registro_de_infraccionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gestion_infracciones1DataSet
            // 
            this.gestion_infracciones1DataSet.DataSetName = "gestion_infracciones1DataSet";
            this.gestion_infracciones1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // registro_de_infraccionBindingSource
            // 
            this.registro_de_infraccionBindingSource.DataMember = "registro_de_infraccion";
            this.registro_de_infraccionBindingSource.DataSource = this.gestion_infracciones1DataSet;
            // 
            // registro_de_infraccionTableAdapter
            // 
            this.registro_de_infraccionTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AMETTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ConductorTableAdapter = null;
            this.tableAdapterManager.registro_de_infraccionTableAdapter = this.registro_de_infraccionTableAdapter;
            this.tableAdapterManager.tipos_de_infraccionesTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = PF.gestion_infracciones1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.vehiculoTableAdapter = null;
            // 
            // cedulaLabel
            // 
            cedulaLabel.AutoSize = true;
            cedulaLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            cedulaLabel.Location = new System.Drawing.Point(54, 123);
            cedulaLabel.Name = "cedulaLabel";
            cedulaLabel.Size = new System.Drawing.Size(102, 33);
            cedulaLabel.TabIndex = 1;
            cedulaLabel.Text = "Cedula:";
            // 
            // cedulaTextBox
            // 
            this.cedulaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.registro_de_infraccionBindingSource, "cedula", true));
            this.cedulaTextBox.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cedulaTextBox.Location = new System.Drawing.Point(219, 129);
            this.cedulaTextBox.Name = "cedulaTextBox";
            this.cedulaTextBox.Size = new System.Drawing.Size(397, 39);
            this.cedulaTextBox.TabIndex = 2;
            // 
            // nombre_conductorLabel
            // 
            nombre_conductorLabel.AutoSize = true;
            nombre_conductorLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            nombre_conductorLabel.Location = new System.Drawing.Point(52, 165);
            nombre_conductorLabel.Name = "nombre_conductorLabel";
            nombre_conductorLabel.Size = new System.Drawing.Size(230, 33);
            nombre_conductorLabel.TabIndex = 3;
            nombre_conductorLabel.Text = "Nombre conductor:";
            // 
            // nombre_conductorTextBox
            // 
            this.nombre_conductorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.registro_de_infraccionBindingSource, "nombre_conductor", true));
            this.nombre_conductorTextBox.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombre_conductorTextBox.Location = new System.Drawing.Point(303, 179);
            this.nombre_conductorTextBox.Name = "nombre_conductorTextBox";
            this.nombre_conductorTextBox.Size = new System.Drawing.Size(313, 39);
            this.nombre_conductorTextBox.TabIndex = 4;
            // 
            // placaLabel
            // 
            placaLabel.AutoSize = true;
            placaLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            placaLabel.Location = new System.Drawing.Point(54, 206);
            placaLabel.Name = "placaLabel";
            placaLabel.Size = new System.Drawing.Size(83, 33);
            placaLabel.TabIndex = 5;
            placaLabel.Text = "Placa:";
            // 
            // placaTextBox
            // 
            this.placaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.registro_de_infraccionBindingSource, "placa", true));
            this.placaTextBox.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.placaTextBox.Location = new System.Drawing.Point(219, 223);
            this.placaTextBox.Name = "placaTextBox";
            this.placaTextBox.Size = new System.Drawing.Size(397, 39);
            this.placaTextBox.TabIndex = 6;
            // 
            // tipo_licenciaLabel
            // 
            tipo_licenciaLabel.AutoSize = true;
            tipo_licenciaLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            tipo_licenciaLabel.Location = new System.Drawing.Point(54, 260);
            tipo_licenciaLabel.Name = "tipo_licenciaLabel";
            tipo_licenciaLabel.Size = new System.Drawing.Size(167, 33);
            tipo_licenciaLabel.TabIndex = 7;
            tipo_licenciaLabel.Text = "Tipo licencia:";
            // 
            // codigo_AMETLabel
            // 
            codigo_AMETLabel.AutoSize = true;
            codigo_AMETLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            codigo_AMETLabel.Location = new System.Drawing.Point(54, 314);
            codigo_AMETLabel.Name = "codigo_AMETLabel";
            codigo_AMETLabel.Size = new System.Drawing.Size(186, 33);
            codigo_AMETLabel.TabIndex = 9;
            codigo_AMETLabel.Text = "Codigo AMET:";
            // 
            // codigo_AMETTextBox
            // 
            this.codigo_AMETTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.registro_de_infraccionBindingSource, "codigo_AMET", true));
            this.codigo_AMETTextBox.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.codigo_AMETTextBox.Location = new System.Drawing.Point(251, 328);
            this.codigo_AMETTextBox.Name = "codigo_AMETTextBox";
            this.codigo_AMETTextBox.Size = new System.Drawing.Size(365, 39);
            this.codigo_AMETTextBox.TabIndex = 10;
            // 
            // descripcion_infraccionesLabel
            // 
            descripcion_infraccionesLabel.AutoSize = true;
            descripcion_infraccionesLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            descripcion_infraccionesLabel.Location = new System.Drawing.Point(52, 370);
            descripcion_infraccionesLabel.Name = "descripcion_infraccionesLabel";
            descripcion_infraccionesLabel.Size = new System.Drawing.Size(299, 33);
            descripcion_infraccionesLabel.TabIndex = 11;
            descripcion_infraccionesLabel.Text = "Descripcion infracciones:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(182, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(382, 47);
            this.label2.TabIndex = 31;
            this.label2.Text = "Registrar infracciones";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightYellow;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(622, 169);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(197, 45);
            this.button1.TabIndex = 32;
            this.button1.Text = "Registrar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightYellow;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(622, 289);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(197, 45);
            this.button2.TabIndex = 32;
            this.button2.Text = "Limpiar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Tipo A (Todo tipo de vehiculos). ",
            "Tipo B (Vehiculos pesados)",
            "Tipo C (Motocicletas). "});
            this.comboBox1.Location = new System.Drawing.Point(233, 278);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(383, 24);
            this.comboBox1.TabIndex = 33;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "- Obstrucción de tránsito con penalidad de RD$ 1800.00, ",
            "- Pase de semáforo en rojo con penalidad de RD$ 5,950.00, ",
            "- Hablar por el celular con penalidad de RD$ 3,750.00, ",
            "- Conducir sin el cinturon con penalidad de RD$ 2.560.00",
            "- Licencia vencida con penalidad de RDS 3,890.00."});
            this.comboBox2.Location = new System.Drawing.Point(363, 387);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(253, 24);
            this.comboBox2.TabIndex = 34;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(31, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 74);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // RegistroInfracc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(831, 478);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(descripcion_infraccionesLabel);
            this.Controls.Add(codigo_AMETLabel);
            this.Controls.Add(this.codigo_AMETTextBox);
            this.Controls.Add(tipo_licenciaLabel);
            this.Controls.Add(placaLabel);
            this.Controls.Add(this.placaTextBox);
            this.Controls.Add(nombre_conductorLabel);
            this.Controls.Add(this.nombre_conductorTextBox);
            this.Controls.Add(cedulaLabel);
            this.Controls.Add(this.cedulaTextBox);
            this.Name = "RegistroInfracc";
            this.Text = "RegistroInfracc";
            this.Load += new System.EventHandler(this.RegistroInfracc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gestion_infracciones1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.registro_de_infraccionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private gestion_infracciones1DataSet gestion_infracciones1DataSet;
        private System.Windows.Forms.BindingSource registro_de_infraccionBindingSource;
        private gestion_infracciones1DataSetTableAdapters.registro_de_infraccionTableAdapter registro_de_infraccionTableAdapter;
        private gestion_infracciones1DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox cedulaTextBox;
        private System.Windows.Forms.TextBox nombre_conductorTextBox;
        private System.Windows.Forms.TextBox placaTextBox;
        private System.Windows.Forms.TextBox codigo_AMETTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}