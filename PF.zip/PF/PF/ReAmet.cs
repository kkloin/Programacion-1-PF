﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;
namespace PF
{
    public partial class ReAmet : Form
    {
        public ReAmet()
        {
            InitializeComponent();
        }
        public void AMETRE()
        {


            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=DESKTOP-HUHEPHT\\SQLEXPRESS;Initial Catalog=gestion_infracciones1;Integrated Security=True";


            conn.Open();

            SqlCommand cmd = new SqlCommand("");

            // cmd.CommandText = "INSERT INTO usuarios_finales (cedula, Nombre_completo, Usuario,Sexo,Fecha_nacimiento, Contraseña,Email) VALUES (@cedula, @Nombre_completo, @Usuario,@Sexo,@Fecha_nacimiento, @Contraseña,@Email)";
            cmd.CommandText = "INSERT INTO AMET (codigo_empleado, nombre_completo, Fecha_de_ingreso) VALUES (@codigo_empleado, @nombre_completo, @Fecha_de_ingreso);"; /*"INSERT INTO prestamos (Monto,Id_tipo_de_prestamos,Balance_Restante) VALUES (@Monto,@Id_tipo_de_prestamos,@Monto);";*/


            // cmd.Parameters.AddWithValue("@Id_usuario", textBox1.Text);
            cmd.Parameters.AddWithValue("@codigo_empleado", codigo_empleadoTextBox.Text);
            cmd.Parameters.AddWithValue("@nombre_completo", nombre_completoTextBox.Text);
            cmd.Parameters.AddWithValue("@Fecha_de_ingreso", fecha_de_ingresoDateTimePicker.Value);
           


            cmd.Connection = conn;

            SqlCommand cmd2 = new SqlCommand();

            cmd2.Connection = conn;

            cmd2.CommandText = "SELECT * FROM AMET";




            cmd.ExecuteNonQuery();


            SqlDataReader dr = cmd2.ExecuteReader();

            DataTable dt = new DataTable();
            if (dr.Read())
            {

                MessageBox.Show("AMET agregado exitosamente!");

            }


            dt.Load(dr);


            //infocedulaDataGridView.DataSource = dt;


            conn.Close();


        }
        private void aMETBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.aMETBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.gestion_infracciones1DataSet);

        }

        private void ReAmet_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'gestion_infracciones1DataSet.AMET' table. You can move, or remove it, as needed.
            this.aMETTableAdapter.Fill(this.gestion_infracciones1DataSet.AMET);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            AMETRE();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            codigo_empleadoTextBox.Clear();
            nombre_completoTextBox.Clear();
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FRMinicio super = new FRMinicio();
            super.Show();
        }
    }
}
