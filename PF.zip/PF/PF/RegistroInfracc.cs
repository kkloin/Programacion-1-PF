﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;

namespace PF
{
    public partial class RegistroInfracc : Form
    {
        public RegistroInfracc()
        {
            InitializeComponent();
        }
        public void crearusuarioinfra()
        {


            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=DESKTOP-HUHEPHT\\SQLEXPRESS;Initial Catalog=gestion_infracciones1;Integrated Security=True";


            conn.Open();

            SqlCommand cmd = new SqlCommand("");

            // cmd.CommandText = "INSERT INTO usuarios_finales (cedula, Nombre_completo, Usuario,Sexo,Fecha_nacimiento, Contraseña,Email) VALUES (@cedula, @Nombre_completo, @Usuario,@Sexo,@Fecha_nacimiento, @Contraseña,@Email)";
            cmd.CommandText = "INSERT INTO registro_de_infraccion (cedula,nombre_conductor, placa, tipo_licencia, codigo_AMET,descripcion_infracciones) VALUES (@cedula,@nombre_conductor, @placa, @tipo_licencia, @codigo_AMET,@descripcion_infracciones);"; /*"INSERT INTO prestamos (Monto,Id_tipo_de_prestamos,Balance_Restante) VALUES (@Monto,@Id_tipo_de_prestamos,@Monto);";*/


            // cmd.Parameters.AddWithValue("@Id_usuario", textBox1.Text);
            cmd.Parameters.AddWithValue("@cedula", cedulaTextBox.Text);
            cmd.Parameters.AddWithValue("@nombre_conductor", nombre_conductorTextBox.Text);
            cmd.Parameters.AddWithValue("@placa", placaTextBox.Text);
            cmd.Parameters.AddWithValue("@tipo_licencia", comboBox1.SelectedItem);
            cmd.Parameters.AddWithValue("@codigo_AMET", codigo_AMETTextBox.Text);
            cmd.Parameters.AddWithValue("@descripcion_infracciones", comboBox2.SelectedItem);


            cmd.Connection = conn;

            SqlCommand cmd2 = new SqlCommand();

            cmd2.Connection = conn;

            cmd2.CommandText = "SELECT * FROM registro_de_infraccion";




            cmd.ExecuteNonQuery();


            SqlDataReader dr = cmd2.ExecuteReader();

            DataTable dt = new DataTable();
            if (dr.Read())
            {

                MessageBox.Show("Infraccion registrada exitosamente!");

            }


            dt.Load(dr);


            //infocedulaDataGridView.DataSource = dt;


            conn.Close();


        }
        private void registro_de_infraccionBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.registro_de_infraccionBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.gestion_infracciones1DataSet);

        }

        private void RegistroInfracc_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'gestion_infracciones1DataSet.registro_de_infraccion' table. You can move, or remove it, as needed.
            this.registro_de_infraccionTableAdapter.Fill(this.gestion_infracciones1DataSet.registro_de_infraccion);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            crearusuarioinfra();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cedulaTextBox.Clear();
            nombre_conductorTextBox.Clear();
            placaTextBox.Clear();
            codigo_AMETTextBox.Clear();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FRMinicio super = new FRMinicio();
            super.Show();
        }
    }
}
