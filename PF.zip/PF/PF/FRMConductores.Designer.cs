﻿
namespace PF
{
    partial class FRMConductores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label cedulaLabel;
            System.Windows.Forms.Label nombre_completoLabel;
            System.Windows.Forms.Label direccionLabel;
            System.Windows.Forms.Label tipo_licenciaLabel;
            System.Windows.Forms.Label fecha_de_nacimientoLabel;
            System.Windows.Forms.Label placaLabel1;
            System.Windows.Forms.Label marcaLabel;
            System.Windows.Forms.Label modeloLabel;
            System.Windows.Forms.Label colorLabel;
            System.Windows.Forms.Label numero_chasisLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FRMConductores));
            this.gestion_infracciones1DataSet = new PF.gestion_infracciones1DataSet();
            this.conductorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.conductorTableAdapter = new PF.gestion_infracciones1DataSetTableAdapters.ConductorTableAdapter();
            this.tableAdapterManager = new PF.gestion_infracciones1DataSetTableAdapters.TableAdapterManager();
            this.cedulaTextBox = new System.Windows.Forms.TextBox();
            this.nombre_completoTextBox = new System.Windows.Forms.TextBox();
            this.direccionTextBox = new System.Windows.Forms.TextBox();
            this.fecha_de_nacimientoDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.Agregar = new System.Windows.Forms.Button();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.numero_chasisTextBox = new System.Windows.Forms.TextBox();
            this.vehiculoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.colorTextBox = new System.Windows.Forms.TextBox();
            this.modeloTextBox = new System.Windows.Forms.TextBox();
            this.marcaTextBox = new System.Windows.Forms.TextBox();
            this.placaTextBox1 = new System.Windows.Forms.TextBox();
            this.vehiculoTableAdapter = new PF.gestion_infracciones1DataSetTableAdapters.vehiculoTableAdapter();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            cedulaLabel = new System.Windows.Forms.Label();
            nombre_completoLabel = new System.Windows.Forms.Label();
            direccionLabel = new System.Windows.Forms.Label();
            tipo_licenciaLabel = new System.Windows.Forms.Label();
            fecha_de_nacimientoLabel = new System.Windows.Forms.Label();
            placaLabel1 = new System.Windows.Forms.Label();
            marcaLabel = new System.Windows.Forms.Label();
            modeloLabel = new System.Windows.Forms.Label();
            colorLabel = new System.Windows.Forms.Label();
            numero_chasisLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gestion_infracciones1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.conductorBindingSource)).BeginInit();
            this.fillByToolStrip.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vehiculoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // cedulaLabel
            // 
            cedulaLabel.AutoSize = true;
            cedulaLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            cedulaLabel.Location = new System.Drawing.Point(45, 122);
            cedulaLabel.Name = "cedulaLabel";
            cedulaLabel.Size = new System.Drawing.Size(102, 33);
            cedulaLabel.TabIndex = 1;
            cedulaLabel.Text = "Cedula:";
            // 
            // nombre_completoLabel
            // 
            nombre_completoLabel.AutoSize = true;
            nombre_completoLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            nombre_completoLabel.Location = new System.Drawing.Point(45, 178);
            nombre_completoLabel.Name = "nombre_completoLabel";
            nombre_completoLabel.Size = new System.Drawing.Size(221, 33);
            nombre_completoLabel.TabIndex = 3;
            nombre_completoLabel.Text = "Nombre completo:";
            // 
            // direccionLabel
            // 
            direccionLabel.AutoSize = true;
            direccionLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            direccionLabel.Location = new System.Drawing.Point(46, 231);
            direccionLabel.Name = "direccionLabel";
            direccionLabel.Size = new System.Drawing.Size(132, 33);
            direccionLabel.TabIndex = 5;
            direccionLabel.Text = "Direccion:";
            // 
            // tipo_licenciaLabel
            // 
            tipo_licenciaLabel.AutoSize = true;
            tipo_licenciaLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            tipo_licenciaLabel.Location = new System.Drawing.Point(47, 284);
            tipo_licenciaLabel.Name = "tipo_licenciaLabel";
            tipo_licenciaLabel.Size = new System.Drawing.Size(167, 33);
            tipo_licenciaLabel.TabIndex = 7;
            tipo_licenciaLabel.Text = "Tipo licencia:";
            // 
            // fecha_de_nacimientoLabel
            // 
            fecha_de_nacimientoLabel.AutoSize = true;
            fecha_de_nacimientoLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            fecha_de_nacimientoLabel.Location = new System.Drawing.Point(44, 338);
            fecha_de_nacimientoLabel.Name = "fecha_de_nacimientoLabel";
            fecha_de_nacimientoLabel.Size = new System.Drawing.Size(251, 33);
            fecha_de_nacimientoLabel.TabIndex = 9;
            fecha_de_nacimientoLabel.Text = "Fecha de nacimiento:";
            // 
            // placaLabel1
            // 
            placaLabel1.AutoSize = true;
            placaLabel1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            placaLabel1.Location = new System.Drawing.Point(39, 143);
            placaLabel1.Name = "placaLabel1";
            placaLabel1.Size = new System.Drawing.Size(83, 33);
            placaLabel1.TabIndex = 0;
            placaLabel1.Text = "Placa:";
            // 
            // marcaLabel
            // 
            marcaLabel.AutoSize = true;
            marcaLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            marcaLabel.Location = new System.Drawing.Point(34, 205);
            marcaLabel.Name = "marcaLabel";
            marcaLabel.Size = new System.Drawing.Size(93, 33);
            marcaLabel.TabIndex = 2;
            marcaLabel.Text = "Marca:";
            // 
            // modeloLabel
            // 
            modeloLabel.AutoSize = true;
            modeloLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            modeloLabel.Location = new System.Drawing.Point(27, 261);
            modeloLabel.Name = "modeloLabel";
            modeloLabel.Size = new System.Drawing.Size(110, 33);
            modeloLabel.TabIndex = 4;
            modeloLabel.Text = "Modelo:";
            // 
            // colorLabel
            // 
            colorLabel.AutoSize = true;
            colorLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            colorLabel.Location = new System.Drawing.Point(34, 311);
            colorLabel.Name = "colorLabel";
            colorLabel.Size = new System.Drawing.Size(87, 33);
            colorLabel.TabIndex = 6;
            colorLabel.Text = "Color:";
            // 
            // numero_chasisLabel
            // 
            numero_chasisLabel.AutoSize = true;
            numero_chasisLabel.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            numero_chasisLabel.Location = new System.Drawing.Point(28, 359);
            numero_chasisLabel.Name = "numero_chasisLabel";
            numero_chasisLabel.Size = new System.Drawing.Size(187, 33);
            numero_chasisLabel.TabIndex = 8;
            numero_chasisLabel.Text = "Numero chasis:";
            // 
            // gestion_infracciones1DataSet
            // 
            this.gestion_infracciones1DataSet.DataSetName = "gestion_infracciones1DataSet";
            this.gestion_infracciones1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // conductorBindingSource
            // 
            this.conductorBindingSource.DataMember = "Conductor";
            this.conductorBindingSource.DataSource = this.gestion_infracciones1DataSet;
            // 
            // conductorTableAdapter
            // 
            this.conductorTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AMETTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ConductorTableAdapter = this.conductorTableAdapter;
            this.tableAdapterManager.registro_de_infraccionTableAdapter = null;
            this.tableAdapterManager.tipos_de_infraccionesTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = PF.gestion_infracciones1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.vehiculoTableAdapter = null;
            // 
            // cedulaTextBox
            // 
            this.cedulaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.conductorBindingSource, "cedula", true));
            this.cedulaTextBox.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cedulaTextBox.Location = new System.Drawing.Point(182, 119);
            this.cedulaTextBox.Name = "cedulaTextBox";
            this.cedulaTextBox.Size = new System.Drawing.Size(404, 39);
            this.cedulaTextBox.TabIndex = 2;
            // 
            // nombre_completoTextBox
            // 
            this.nombre_completoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.conductorBindingSource, "nombre_completo", true));
            this.nombre_completoTextBox.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombre_completoTextBox.Location = new System.Drawing.Point(282, 175);
            this.nombre_completoTextBox.Name = "nombre_completoTextBox";
            this.nombre_completoTextBox.Size = new System.Drawing.Size(304, 39);
            this.nombre_completoTextBox.TabIndex = 4;
            // 
            // direccionTextBox
            // 
            this.direccionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.conductorBindingSource, "direccion", true));
            this.direccionTextBox.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.direccionTextBox.Location = new System.Drawing.Point(282, 231);
            this.direccionTextBox.Name = "direccionTextBox";
            this.direccionTextBox.Size = new System.Drawing.Size(304, 39);
            this.direccionTextBox.TabIndex = 6;
            // 
            // fecha_de_nacimientoDateTimePicker
            // 
            this.fecha_de_nacimientoDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.conductorBindingSource, "fecha_de_nacimiento", true));
            this.fecha_de_nacimientoDateTimePicker.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fecha_de_nacimientoDateTimePicker.Location = new System.Drawing.Point(311, 332);
            this.fecha_de_nacimientoDateTimePicker.Name = "fecha_de_nacimientoDateTimePicker";
            this.fecha_de_nacimientoDateTimePicker.Size = new System.Drawing.Size(275, 39);
            this.fecha_de_nacimientoDateTimePicker.TabIndex = 10;
            // 
            // Agregar
            // 
            this.Agregar.BackColor = System.Drawing.Color.LightYellow;
            this.Agregar.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Agregar.Location = new System.Drawing.Point(69, 417);
            this.Agregar.Name = "Agregar";
            this.Agregar.Size = new System.Drawing.Size(188, 49);
            this.Agregar.TabIndex = 13;
            this.Agregar.Text = "Registrar";
            this.Agregar.UseVisualStyleBackColor = false;
            this.Agregar.Click += new System.EventHandler(this.Agregar_Click);
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByToolStripButton});
            this.fillByToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(1313, 27);
            this.fillByToolStrip.TabIndex = 14;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(48, 24);
            this.fillByToolStripButton.Text = "FillBy";
            this.fillByToolStripButton.Click += new System.EventHandler(this.fillByToolStripButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(88, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(409, 47);
            this.label2.TabIndex = 31;
            this.label2.Text = "Registro de conductores";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.fecha_de_nacimientoDateTimePicker);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cedulaTextBox);
            this.groupBox1.Controls.Add(cedulaLabel);
            this.groupBox1.Controls.Add(this.Agregar);
            this.groupBox1.Controls.Add(this.nombre_completoTextBox);
            this.groupBox1.Controls.Add(nombre_completoLabel);
            this.groupBox1.Controls.Add(this.direccionTextBox);
            this.groupBox1.Controls.Add(fecha_de_nacimientoLabel);
            this.groupBox1.Controls.Add(direccionLabel);
            this.groupBox1.Controls.Add(tipo_licenciaLabel);
            this.groupBox1.Location = new System.Drawing.Point(684, 88);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(607, 524);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "conductores";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(136, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(365, 47);
            this.label1.TabIndex = 31;
            this.label1.Text = "Registro de vehiculos";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(numero_chasisLabel);
            this.groupBox2.Controls.Add(this.numero_chasisTextBox);
            this.groupBox2.Controls.Add(colorLabel);
            this.groupBox2.Controls.Add(this.colorTextBox);
            this.groupBox2.Controls.Add(modeloLabel);
            this.groupBox2.Controls.Add(this.modeloTextBox);
            this.groupBox2.Controls.Add(marcaLabel);
            this.groupBox2.Controls.Add(this.marcaTextBox);
            this.groupBox2.Controls.Add(placaLabel1);
            this.groupBox2.Controls.Add(this.placaTextBox1);
            this.groupBox2.Location = new System.Drawing.Point(91, 88);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(568, 524);
            this.groupBox2.TabIndex = 33;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "vehiculos";
            // 
            // numero_chasisTextBox
            // 
            this.numero_chasisTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vehiculoBindingSource, "numero_chasis", true));
            this.numero_chasisTextBox.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numero_chasisTextBox.Location = new System.Drawing.Point(233, 359);
            this.numero_chasisTextBox.Name = "numero_chasisTextBox";
            this.numero_chasisTextBox.Size = new System.Drawing.Size(216, 39);
            this.numero_chasisTextBox.TabIndex = 9;
            // 
            // vehiculoBindingSource
            // 
            this.vehiculoBindingSource.DataMember = "vehiculo";
            this.vehiculoBindingSource.DataSource = this.gestion_infracciones1DataSet;
            // 
            // colorTextBox
            // 
            this.colorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vehiculoBindingSource, "color", true));
            this.colorTextBox.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colorTextBox.Location = new System.Drawing.Point(158, 311);
            this.colorTextBox.Name = "colorTextBox";
            this.colorTextBox.Size = new System.Drawing.Size(291, 39);
            this.colorTextBox.TabIndex = 7;
            // 
            // modeloTextBox
            // 
            this.modeloTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vehiculoBindingSource, "modelo", true));
            this.modeloTextBox.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modeloTextBox.Location = new System.Drawing.Point(158, 267);
            this.modeloTextBox.Name = "modeloTextBox";
            this.modeloTextBox.Size = new System.Drawing.Size(291, 39);
            this.modeloTextBox.TabIndex = 5;
            // 
            // marcaTextBox
            // 
            this.marcaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vehiculoBindingSource, "marca", true));
            this.marcaTextBox.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.marcaTextBox.Location = new System.Drawing.Point(158, 205);
            this.marcaTextBox.Name = "marcaTextBox";
            this.marcaTextBox.Size = new System.Drawing.Size(291, 39);
            this.marcaTextBox.TabIndex = 3;
            // 
            // placaTextBox1
            // 
            this.placaTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vehiculoBindingSource, "placa", true));
            this.placaTextBox1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.placaTextBox1.Location = new System.Drawing.Point(158, 149);
            this.placaTextBox1.Name = "placaTextBox1";
            this.placaTextBox1.Size = new System.Drawing.Size(291, 39);
            this.placaTextBox1.TabIndex = 1;
            // 
            // vehiculoTableAdapter
            // 
            this.vehiculoTableAdapter.ClearBeforeFill = true;
            // 
            // comboBox1
            // 
            this.comboBox1.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.conductorBindingSource, "tipo_licencia", true));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Tipo A (Todo tipo de vehiculos)",
            "Tipo B (Vehiculos pesados)",
            "Tipo C (Motocicletas)"});
            this.comboBox1.Location = new System.Drawing.Point(282, 292);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(304, 24);
            this.comboBox1.TabIndex = 34;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightYellow;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(377, 418);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(199, 47);
            this.button1.TabIndex = 35;
            this.button1.Text = "Limpiar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightYellow;
            this.button3.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(45, 421);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(191, 44);
            this.button3.TabIndex = 34;
            this.button3.Text = "Registrar";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightYellow;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(327, 422);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(191, 44);
            this.button2.TabIndex = 34;
            this.button2.Text = "Limpiar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 39);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 74);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FRMConductores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1313, 635);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.fillByToolStrip);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "FRMConductores";
            this.Text = "FRMConductores";
            this.Load += new System.EventHandler(this.FRMConductores_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gestion_infracciones1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.conductorBindingSource)).EndInit();
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vehiculoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private gestion_infracciones1DataSet gestion_infracciones1DataSet;
        private System.Windows.Forms.BindingSource conductorBindingSource;
        private gestion_infracciones1DataSetTableAdapters.ConductorTableAdapter conductorTableAdapter;
        private gestion_infracciones1DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox cedulaTextBox;
        private System.Windows.Forms.TextBox nombre_completoTextBox;
        private System.Windows.Forms.TextBox direccionTextBox;
        private System.Windows.Forms.DateTimePicker fecha_de_nacimientoDateTimePicker;
        private System.Windows.Forms.Button Agregar;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.BindingSource vehiculoBindingSource;
        private gestion_infracciones1DataSetTableAdapters.vehiculoTableAdapter vehiculoTableAdapter;
        private System.Windows.Forms.TextBox numero_chasisTextBox;
        private System.Windows.Forms.TextBox colorTextBox;
        private System.Windows.Forms.TextBox modeloTextBox;
        private System.Windows.Forms.TextBox marcaTextBox;
        private System.Windows.Forms.TextBox placaTextBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}