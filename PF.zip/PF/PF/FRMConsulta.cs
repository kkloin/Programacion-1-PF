﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PF
{
    public partial class FRMConsulta : Form
    {
        public FRMConsulta()
        {
            InitializeComponent();
        }

       

        private void registro_de_infraccionBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.registro_de_infraccionBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.gestion_infracciones1DataSet);

        }

        private void FRMConsulta_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'gestion_infracciones1DataSet.AMET' table. You can move, or remove it, as needed.
            this.aMETTableAdapter.Fill(this.gestion_infracciones1DataSet.AMET);
            // TODO: This line of code loads data into the 'gestion_infracciones1DataSet.vehiculo' table. You can move, or remove it, as needed.
            this.vehiculoTableAdapter.Fill(this.gestion_infracciones1DataSet.vehiculo);
            // TODO: This line of code loads data into the 'gestion_infracciones1DataSet.Conductor' table. You can move, or remove it, as needed.
            this.conductorTableAdapter.Fill(this.gestion_infracciones1DataSet.Conductor);
            // TODO: This line of code loads data into the 'gestion_infracciones1DataSet.registro_de_infraccion' table. You can move, or remove it, as needed.
            this.registro_de_infraccionTableAdapter.Fill(this.gestion_infracciones1DataSet.registro_de_infraccion);

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FRMinicio super = new FRMinicio();
            super.Show();
        }
    }
}
