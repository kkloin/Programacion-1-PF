﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PF
{
    public partial class FRMinicio : Form
    {
        public FRMinicio()
        {
            InitializeComponent();
        }

        private void conductorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.conductorBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.gestion_infracciones1DataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'gestion_infracciones1DataSet.Conductor' table. You can move, or remove it, as needed.
            this.conductorTableAdapter.Fill(this.gestion_infracciones1DataSet.Conductor);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FRMConsulta consul = new FRMConsulta();
            consul.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FRMConductores consul = new FRMConductores();
            consul.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegistroInfracc super = new RegistroInfracc();
            super.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReAmet super = new ReAmet();
            super.Show();
        }
    }
}
